//package CreatingInvertedIndex;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class InvertedIndexDriver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		String inpath = args[0];
		String outpath = args[1];
		int NUM = Integer.parseInt(args[2]);
		
		// job configuration
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Creating Inverted Index");
		job.setJarByClass(InvertedIndexDriver.class);
		// specify a mapper
		job.setMapperClass(InvertedIndexMapper.class); 
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Posting.class);
		
		// specify a reducer
		job.setReducerClass(InvertedIndexReducer.class);
		
		// specify a combiner
		job.setCombinerClass(InvertedIndexCombiner.class);

		// specify output types
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		// set number of reducer
		job.setNumReduceTasks(NUM);

		// specify Input/Output Format
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		// specify input and output DIRECTORIES (not files)
		FileInputFormat.setInputDirRecursive(job, true);
		FileInputFormat.setInputPaths(job, new Path(inpath));
		FileOutputFormat.setOutputPath(job, new Path(outpath));
		job.waitForCompletion(true);
		System.out.println("Finish Indexing!!");
	}
}
