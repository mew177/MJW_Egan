//package Search;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueLineRecordReader;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class SearchDriver {

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		// user input requests
		String inputSrc = args[0];
		String outputDes = args[1];
		String keyWords = "";
		for(int i=2;i<args.length;i++)
			keyWords = keyWords + " " + args[i];
		
		conf.set("keyWords",keyWords);
		
		Job job = Job.getInstance(conf, "Search");
		job.setJarByClass(SearchDriver.class);
		
		// set mapper class
		job.setMapperClass(SearchMapper.class);
		job.setReducerClass(SearchReducer.class);
		
		// set output
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(LongWritable.class);
		
		job.setInputFormatClass(KeyValueTextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.setInputDirRecursive(job,true);
		// TODO: specify input and output DIRECTORIES (not files)
		FileInputFormat.setInputPaths(job, new Path(inputSrc));
		FileOutputFormat.setOutputPath(job, new Path(outputDes));

		System.exit(job.waitForCompletion(true)?0:1);
	}

}
