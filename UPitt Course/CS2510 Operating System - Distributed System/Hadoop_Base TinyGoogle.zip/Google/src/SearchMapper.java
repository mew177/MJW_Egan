//package Search;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SearchMapper extends Mapper<Text, PostingList, Text, LongWritable> {

	public void map(Text key, PostingList values, Context context) throws IOException, InterruptedException {
		
		Configuration conf = context.getConfiguration();
		
		StringTokenizer itr = new StringTokenizer(conf.get("keyWords"), " ");
		while(itr.hasMoreTokens()) {
			String keyword = itr.nextToken();
			if(key.toString().equals(keyword))
				for(Posting p: values.getList())
					context.write(new Text(p.getFile()), new LongWritable(Long.valueOf(p.getCount())));
		}		
	}
}
