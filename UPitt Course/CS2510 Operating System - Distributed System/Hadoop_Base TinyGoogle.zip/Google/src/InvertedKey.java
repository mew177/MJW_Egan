import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class InvertedKey implements WritableComparable<InvertedKey>{

	private String word;
	private String doc;
	private int count;
	
	public InvertedKey() {
		this.word = "N/A";
		this.doc = "N/A";
		this.count = 0;
	}
	
	public InvertedKey(String word, String doc, int count) {
		this.word = word;
		this.doc = doc;
		this.count = count;
	}
	
	public void setWord(String word) {
		this.word = word;
	}
	
	public void setDoc(String doc) {
		this.doc = doc;
	}
	
	public void setCount(int count) {
		this.count = count;
	}	
	
	public void addCount() {
		this.count += 1;
	}
	
	public String getWord() {
		return word;
	}
	
	public String getDoc() {
		return doc;
	}
	
	public int getCount() {
		return count;
	}

	public void readFields(DataInput in) throws IOException {
		this.word = in.readUTF();
		this.doc = in.readUTF();
		this.count = in.readInt();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(word);
		out.writeUTF(doc);
		out.writeInt(count);
	}
	
	public boolean isSameIndex(InvertedKey IK) {
		if(IK.getWord().equals(word))
			if(IK.getDoc().equals(doc)) 
				return true;
		return false;
	}

	@Override
	public int compareTo(InvertedKey InK) {
		InvertedKey IK = (InvertedKey) InK;
		if(this.isSameIndex(IK))
			return 0;
		else
			return 1;
	}
}
