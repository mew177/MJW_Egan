//package CreatingInvertedIndex;

import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class InvertedIndexReducer extends Reducer<Text, Posting, Text, PostingList> {

	public void reduce(Text key, Iterable<Posting> values, Context context) throws IOException, InterruptedException {
		HashMap<String, Integer> map=new HashMap<String,Integer>();
		
		// reduce record of each <word, Posting> from different Mapper
		for(Posting posting: values) {
			String fileName = posting.getFile();
			int value = posting.getCount();
			if(!map.containsKey(fileName))
				map.put(fileName, value);
			else
				map.put(fileName, map.get(fileName) + value);
		}
		
		// write into PostingList form
		PostingList list = new PostingList(key.toString());
		for(String fileName: map.keySet())
			list.addPosting(new Posting(key.toString(), fileName, map.get(fileName)));
		context.write(key, list);
		
		/*** do this step instead of previous, if you want to search ***/
		/*
		// set output format as Text
		String rep = "";
		boolean first = true;
		
		// write into Text form
		for(String fileName: map.keySet()) {
			if(first) {
				rep = rep + fileName + "@" + map.get(fileName);
				first = false;
			} else
				rep = rep + "," + fileName + "@" + map.get(fileName);
		}
		context.write(key, new Text(rep));
		*/
	}

}
