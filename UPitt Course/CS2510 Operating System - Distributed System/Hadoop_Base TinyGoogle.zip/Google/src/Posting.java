import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class Posting implements WritableComparable<Posting>{
	
	private String word;
	private String file;
	private int count;
	
	public Posting(String word, String file, int count) {
		this.word = word;
		this.file = file;
		this.count = count;
	}
	
	public Posting() {
		this.word = "N/A";
		this.file = "N/A";
		this.count = 0;
	}
	
	public void setWord(String word) {
		this.word = word;
	}
	
	public void setFile(String file) {
		this.file = file;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
	
	public void add(int count) {
		this.count += count;
	}
	
	public String getWord() {
		return word;
	}
	
	public String getFile() {
		return file;
	}
	
	public int getCount() {
		return count;
	}
	
	public void addCount() {
		count += 1;
	}

	public void readFields(DataInput in) throws IOException {
		file = in.readUTF();
		count = in.readInt();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(file);
		out.writeInt(count);
	}

	public boolean isSameFile() {
		
		
		return false;
	}
	
	@Override
	public int compareTo(Posting o) {
		
		return 0;
	}
	
	
}
