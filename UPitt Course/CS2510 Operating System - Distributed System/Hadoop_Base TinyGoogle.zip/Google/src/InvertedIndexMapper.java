//package CreatingInvertedIndex;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class InvertedIndexMapper extends Mapper<LongWritable, Text, Text, Posting> {
	
	public void map(LongWritable ikey, Text ivalue, Context context) throws IOException, InterruptedException {
		String fileName = ((FileSplit)context.getInputSplit()).getPath().toString();
		Posting posting = new Posting();
				
		// eliminater & regular expression statement
		String eliminaters = " |$&!@?^*_=+/#[]/\t/\r;:,.()\'\"";
		String regular_expression_1 = "[a-zA-Z]+-[a-zA-Z]+";
		String regular_expression_2 = "[a-zA-Z]+";
		
		// parse line into words token
		StringTokenizer itr = new StringTokenizer(ivalue.toString(), eliminaters);
		String word = "";
		while(itr.hasMoreTokens()) {
			// set them all into lower case
			word = itr.nextToken().toLowerCase();
			// if word match the rules of regular expression "XXXX" or "XXXX-XXXX"
			if(word.matches(regular_expression_1) || word.matches(regular_expression_2)) {
				// write this record as Posting
				posting.setWord(word);
				posting.setFile(fileName);
				posting.setCount(1);
				
				context.write(new Text(word), posting);
			}
		}
	}
}
