import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class InvertedIndexCombiner extends Reducer<Text, Posting, Text, Posting> {
	
	public void reduce(Text key, Iterable<Posting> values, Context context) throws IOException, InterruptedException {
		HashMap<String, Integer> map = new HashMap<>();
				
		// each key(Word) with its values(Postings)
		// combine them first in Mapper process
		// if same word appears in the same file, combine them
		for(Posting posting: values) {
			if(!map.containsKey(posting.getFile())) {
				map.put(posting.getFile(), posting.getCount());
			} else {
				map.put(posting.getFile(), map.get(posting.getFile()) + posting.getCount());
			}
		}
		
		// send record "<word, posting>" to reducer
		// posting => (word, file name, occurance in this file)
		Posting posting = new Posting();
		for(String file: map.keySet()) {
			posting.setFile(file);
			posting.setWord(key.toString());
			posting.setCount(map.get(file));
			context.write(key, posting);
		}
	}
}
