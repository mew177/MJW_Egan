import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.io.WritableComparable;

public class PostingList implements WritableComparable<PostingList> {
	
	private String word;
	//private LinkedList<Posting> list;
	private String list;
	private ArrayList<Posting> lists;
	
	public PostingList(String word) {
		this.word = word;
		this.list = "";
		this.lists = new ArrayList<>();
	}
	
	public String getWord() {
		return word;
	}
	
	public ArrayList<Posting> getList() {
		return lists;
	}
	
	public void addPosting(Posting posting) {
		this.list = list + posting.getFile() + "," + posting.getCount() + ";";
	}

	public void readFields(DataInput in) throws IOException {
		word = in.readUTF();
		list = in.readUTF();
	}

	public void write(DataOutput out) throws IOException {
		out.writeUTF(word);
		out.writeUTF(list);
	}

	public int compareTo(PostingList in) {
		PostingList list2 = (PostingList)in;
		return list2.getWord().hashCode() - word.hashCode();
	}
	
	public int indexOf(String tagetFileName) {
		StringTokenizer itr = new StringTokenizer(list, ";");
		int count = 0;
		while(itr.hasMoreTokens()) {
			String post = itr.nextToken();
			String[] record = post.split(",");
			if(record[0].equals(tagetFileName))
				return count;
			count++;
		}
		return -1;
	}
	
	
}
