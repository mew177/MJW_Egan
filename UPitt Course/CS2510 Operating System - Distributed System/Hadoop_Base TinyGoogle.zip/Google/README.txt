A. Running Inverted Indexing
	1. run this java script with three parameters
		- args[0]: input files directory
		- args[1]: output files directory
		- args[2]: number of reducer you want to include
B. Running Search 
	1. run this java script with at least two parameters
		- args[0]: index source file directory
		- args[1]: output files directory
		- args[>2]: all keyword you want to include and separate with space