
public class WorkerConfig {
	
	private String IP;
	private int PORT;
	
	public WorkerConfig(String IP, int PORT) {
		this.IP = IP;
		this.PORT = PORT;
	}
	
	public String getIP() {
		return IP;
	}
	
	public int getPORT() {
		return PORT;
	}

	public boolean equals(WorkerConfig w2) {
		if(this.IP.equals(w2.getIP()))
			if(this.PORT == w2.getPORT())
				return true;
		return false;
	}
}
