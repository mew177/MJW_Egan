/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package face_pull;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author brantxu
 */
public class WorkerAssigner extends Thread {

    private Socket socket;
    private ObjectInputStream input;
    private static int startPort = 10000;
    private static int endPort = 15000;
    private static int currentPort = startPort;

    public WorkerAssigner(Socket socket) {
        this.socket=socket;
        System.out.printf("Worker is on and running on %s:%d\n", socket.getInetAddress().toString(), socket.getPort());
    }

    public void run() {

        try {
            input = new ObjectInputStream(socket.getInputStream());
            Config config = (Config) input.readObject();
        //    System.out.println("Config received: "+config.toString());

            switch (config.getType()) {
                case 0:
                    new Mapper((MapperConfig)config.getConfig()).start();
                    break;

                case 1:
                    
                    new Reducer((ReducerConfig)config.getConfig()).start();
                    break;

                case 2:

                    boolean ifFound = false;

                    while (!ifFound) {
                        currentPort++;
                        if (currentPort > endPort) {
                            currentPort = startPort;
                        }
                        if (available(currentPort)) {

                            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                            dos.writeInt(currentPort);
                            dos.close();
                            ifFound = true;
                        }
                        

                    }

                    break;
                    
                case 3:
               //     System.out.println("WorkerAssigner receive search");
                    new Searcher((SearcherConfig)config.getConfig(),socket).start();
                    break;

            }

        } catch (IOException ex) {
            Logger.getLogger(WorkerAssigner.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(WorkerAssigner.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static boolean available(int port) {
      //  System.out.println("--------------Testing port " + port);
        Socket s = null;
        try {
            s = new Socket("127.0.0.1", port);

            // If the code makes it this far without an exception it means
            // something is using the port and has responded.
         //   System.out.println("--------------Port " + port + " is not available");
            return false;
        } catch (IOException e) {
          //  System.out.println("--------------Port " + port + " is available");
            return true;
        } finally {
            if (s != null) {
                try {
                    s.close();
                } catch (IOException e) {
                    throw new RuntimeException("You should handle this error.", e);
                }
            }
        }
    }
}
