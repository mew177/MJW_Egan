/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package face_pull;

import java.util.ArrayList;

/**
 *
 * @author brantxu
 */
public class QueryRequest {
        private ArrayList<String> keyWords=new ArrayList<String>();
        
        
        
}
