
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package face_pull;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 *
 * @author brantxu
 */
public class WorkerServer {
	
	public static void main(String[] args) throws IOException {

		int PORT = 9000;
		
		if(args.length > 0)
			PORT = Integer.parseInt(args[0]);
		register(args, PORT);
		ServerSocket serverSocket = new ServerSocket(PORT);
		System.out.printf("worker up and running on %s:%d",serverSocket.getInetAddress().toString(), serverSocket.getLocalPort());
		while (true) {
			new WorkerAssigner(serverSocket.accept()).start();
		}
	}
	
	private static void register(String[] args, int PORT) throws UnknownHostException, IOException {
		int port = 8888;
		String IP = "127.0.0.1";
		
		if(args.length > 2) {
			IP = args[1];
			port = Integer.parseInt(args[2]);
		}
		
		Socket socket = new Socket(IP, port);
		ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
		Request request = new Request(2);
		request.setIP(socket.getLocalAddress().toString().substring(1));
		request.setPORT(PORT);
		out.writeObject(request);
		System.out.printf("Worker on %s:%d has send registration\n", socket.getLocalAddress().toString(), PORT);
		out.close();
		socket.close();
	}
}
