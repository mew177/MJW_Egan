/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package face_pull;

import java.io.IOException;
import java.net.ServerSocket;

/**
 *
 * @author Egan
 */
public class MasterServer {
    public static void main(String[] args) throws IOException{
    	int PORT = 8888;
    	if(args.length > 0)
    		PORT = Integer.parseInt(args[0]);
        ServerSocket google=new ServerSocket(PORT);
        System.out.printf("Master Server is running on %s \n", google.getLocalSocketAddress());
        
        while(true){            
            new Master(google.accept()).start();
        }
    }
}
