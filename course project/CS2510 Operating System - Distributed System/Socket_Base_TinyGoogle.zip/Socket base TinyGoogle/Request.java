
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package face_pull;

import java.io.Serializable;

/**
 *
 * @author Egan
 */
public class Request implements Serializable {

	private String File_Directory;
	private int type;
	private String query;
	private String IP;
	private int PORT;

	public Request(int type) {
		this.type = type;
		this.File_Directory = null;
		this.query = null;
		this.IP = null;
		this.PORT = -1;
	}

	public String getFileDirectory() {
		return this.File_Directory;
	}

	public void addQuery(String query) {
		this.query = query;
	}

	public void addFileDirectory(String fileDirectory) {
		this.File_Directory = fileDirectory;
	}

	public void setIP(String IP) {
		this.IP = IP;
	}

	public void setPORT(int PORT) {
		this.PORT = PORT;
	}

	public String getQuery() {
		return query;
	}

	public int getType() {
		return type;
	}

	public String getIP() {
		return IP;
	}

	public int getPORT() {
		return PORT;
	}

	public String toString() {
		if (type == 0)
			return "IndexRequest type:" + this.type + ", dir:" + this.File_Directory;
		else if (type == 1)
			return "Query type:" + this.type + ", raw query" + this.query;
		else if (type == 2)
			return "Registration type:" + this.type + ", IP:" + this.IP;
		else
			return "wrong request";
	}
}
