To run this socket base TinyGoogle, please follow these steps:
1. Start MasterServer.java
	- default port is 8888
	- RUN java MasterServer <Custom port>, to customize

2. Start WorkerServer.java
	- default port number for WorkerServer is port 9000
	- default worker registration IP and port is "127.0.0.1" and 8888
	- RUN java MasterServer <Custom WorkerServer port> <MasterServer IP> <MasterServer Port>, to customize

3. Set up any numbers of WorkerServer you want

4. Start Client.java
	- default MasterServer IP and port is "127.0.0.1" and 8888
	- RUN java Client <MasterServer IP> <MasterServer Port>, to customize

5. Two type of request can be sent by client
	- type "Index": please type "index", then give directory of files that you want to index
	- type "Search": please type "search", then give one or multiple keywords and separate them with blank
		- type 0 for searching rank: total sum of existence of each keyword in each file
		- type 1 for searching rank: existence of each keyword in each file
