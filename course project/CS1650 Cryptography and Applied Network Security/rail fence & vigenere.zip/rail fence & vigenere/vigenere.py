#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 24 23:28:43 2018
# Vigenere Cipher
@author: Meng Ju, Wu; mew177
"""
# eliminate non-alphabet characters
def cipherTextCleanup(cipher):
    cleaned = ""
    for c in cipher:
        if c.isalpha():
            cleaned += c.lower()
    return cleaned

# find each possible seq and its occurance in message
def KasiskiExam(message):    
    seqSpace = {}
    # search terms from len 3~ 10
    for seqLength in range(3, 10):
        for start in range(len(message) - seqLength):
            seq = message[start: start + seqLength]
            
            # find occurance of each existing term
            for i in range(start, (len(message)-seqLength)):
                if message[i:i+seqLength] == seq:
                    if seq not in seqSpace:
                        seqSpace[seq] = []                  
                    seqSpace[seq].append(i - start)
    
    # remove duplicate items
    result = {}
    for key in seqSpace:
        duplicate = False
        if len(seqSpace[key]) > 1:
            for x in seqSpace[key]:
                if x != 0 or not duplicate:
                    duplicate = True
                    if key not in result:
                        result[key] = []
                    result[key].append(x)
    
    return result
    

# find distance between repeated terms
def findFactor(seqSpace):
    factors = []
    terms = []
    for term in seqSpace:
        # if occurance is larger than 2
        # this record is useful
        if len(seqSpace[term]) > 2:
            terms.append(term)
            for i in range(1, len(seqSpace[term])):
                # distance between repeated terms
                factor = seqSpace[term][i]-seqSpace[term][i-1]
                if factor > 0:
                    factors.append(factor)
    print("repeated terms:")
    print(terms)
    print("")
    print("Distance Between: ")
    return factors

# find most frequecy of each possible factors
def findPossibleFactors(factors):
    freq = {}
    # factorized every numbers
    for factor in factors:
        # we don't need factor of 1
        for i in range(2, factor):
            if factor % i == 0:
                if i not in freq:
                    freq[i] = 1
                freq[i] += 1
            
    # find most appearing factors
    freq = sorted(freq.items(), key=lambda i: i[1])

    return freq[::-1]

# find possible shifts by guessing terms with ciphertext
def findShift(keywords):
    possibleKeys = []
    # go over each keywords
    # compare each cipher text character with guessing plain text character
    for keyword in keywords:
        key = []
        for i in range(len(keyword[0])):
            # calculate the shifting
            shift = ord(keyword[0][i]) - ord(keyword[1][i]) + 26
            key.append(shift)
        possibleKeys.append(key)
    return possibleKeys

# try possible shifts with each possible key length
# if the combination appears some readable text,
# that must be the key    
def tryShifts(keyLengths, shifts):
    trytext = cipher[0: max(keyLengths)]
      
    line = ""
    for c in trytext:
        for shift in shifts:
            line += charShift(c, shift)
            line += " "
        line += "\n"
    print(line)
    
# shift character    
def charShift(c, shift):
    # use ascii code to shift character
    index = ord(c)+shift
    if index > 122:
        index -= 26
    return chr(index)        

# attempt to find some readable text with possible subkey
def trySubkey(subkeys):
    # testing possible subkeys
    trytext = cipher[0: 30]
    
    for subkey in subkeys:
        for k in range(len(subkey)):
            decrypt = ""
            # shifting each subkey 
            for i in range(len(trytext)):
                decrypt += charShift(trytext[i], subkey[(i+k)%len(subkey)])
            print(subkey, k, decrypt)


def decrypt(cipher, key):
    # decrypt cipher text with key
    decrypt = ""
    for i in range(len(cipher)):
        decrypt += charShift(cipher[i], key[i%len(key)])
    print(decrypt)


################ Following is the executing part #############

f = open("part2-cipher.txt", 'r')
cipher = f.read()
cipher = cipherTextCleanup(cipher)
print("\n=== Step 1: find repeated terms =============")
seqSpace = KasiskiExam(cipher)
print(seqSpace)
print("\n=== Step 2: find distance between repeated terms =============")
factors = findFactor(seqSpace)
print(factors)
print("\n=== Step 3: find factors of each distance =============")
possibleKeyLen = findPossibleFactors(factors)
print("most possible key length (Top 3):")
lens = [possibleKeyLen[i][0] for i in range(0, 3)]
print(lens)
print("\n=== Step 4: find possible shifts by known terms ===========")
print("Observing with cipher code, we may guess some possible ")
print("Guessing plaintext of ciphertext:")
print("abc => anx")
print("abc => vft")
print("cs => xw")
print("a => v ")
print("Based on these observation, we can guess key faster.")
keywords = [ ("abc","anx"), ("abc","vft"), ("cs","xw"), ("a","v"), ("a", "e"), ("a", "r"), ("a", "n"), ("a", "m") ]
shifts = findShift(keywords)
print("These are shifts: " , shifts)
print("\n=== Step 5: find possible subkeys ===========")
subkeys = findShift(keywords)
print(subkeys)
print("\n=== Step 6: Merge subkey ===========")
print("Assume there is no letter repeated.")
print("So far, we found 6 unique shifting key. That is to say, key length has at least to be 6 characters")
print("Based on previos subkeys, we can conclude that [26, 14, 5, 22, 9] [13]")
print("are possibly substring if key length is 6")
print("So I try [13, 26, 14, 5, 22, 9]")
print("\n=== Step 7: decrypt with these subkeys ===========")
print("try key length of 6")
mergedKeys = [[13, 26, 14, 5, 22, 9]]
trySubkey(mergedKeys)
print("\n=== Step 8: find the actual key ===========")
print("Luckily we found the right key!!! ")
print("key is [13, 26, 14, 5, 22, 9] with 3 shift")
print("That is [5, 22, 9, 13, 26, 14]")
print("Let's try this key!!!")
print("\n=== Step 9: decrypt whole file ===========")
decrypt(cipher, [5, 22, 9, 13, 26, 14])
