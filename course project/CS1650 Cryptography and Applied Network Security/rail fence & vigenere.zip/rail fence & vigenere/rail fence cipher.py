#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 23 13:17:37 2018
# Rail Fence Cipher
@author: Meng Ju, Wu; mew177
"""

cipher1 = "goapsesnrbvltoameyeeefseaoctptsntuoeohitjhmdnig"
cipher2 = "tlethgytecnfoeneenolaroictepamuonytloexosemcdphemttfsnuadtephstitstear"
cipher3 = "tlctubnseweieestheaorstucingaeiiitusihbttaenxosseretedohmndtnfldcwehirteetetioaoeiwryhvrhnx"

# key of cipher1 = 6
# key of cipher2 = 6
# key of cipher3 = 6

cipher = cipher3

# brute force with key from 1 ~ 20
for row in range(1, 20):
    result = []
    # if cipher text is not evenly divided by f
    # 'extra' shows how many extra character
    extra = len(cipher) % row
    # how many character in each row
    column = len(cipher) // row
    
    # start parsing each row
    start = 0
    end = 0
    for _ in range(row):
        start = end
        end = start + column
        # if there is extra left, parse one more character
        # seperate extra into each row
        if extra > 0:
            end += 1
            extra -= 1
        result.append(cipher[start:end])
    print("====" + str(row) + "=====")
    plaintext = ""
    
    for i in range(len(cipher)):
        plaintext += result[i%row][i//row]
    print(plaintext)
    

